function Awal() //berfungsi untuk mengubah foto profil ke foto awal ketika mouse di jauhkan dari objek foto
		{
			document.getElementById("photo-profile").src ="assets/image/AdamArnap.jpeg";
		}
function Berubah() //berfungsi untuk mengubah foto profil ke foto baru ketika mouse di arahkan ke object foto
		{
			document.getElementById("photo-profile").src ="assets/image/AdamArnapJavaScriptEffect.JPG";
		}